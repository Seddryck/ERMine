﻿using System;
using NUnit.Framework;
using System.Linq;
using ERMine;

namespace ERMine.UnitTesting.Parsing
{
    [TestFixture]
    public class EntityParserTest
    {
        [Test]
        public void entity_OneWord_Label()
        {
            var input = "[Student]";
            var entity = ERMine.Parsing.Entity.Parse(input);

            Assert.AreEqual("Student", entity.Label);

        }

        [Test]
        public void entity_SeveralWord_Label()
        {
            var input = "[Student of University]";
            var entity = ERMine.Parsing.Entity.Parse(input);

            Assert.AreEqual("Student of University", entity.Label);

        }

        [Test]
        public void entity_SeveralWordLineEnd_Label()
        {
            var input = "[Student of University]\r\n******";
            var entity = ERMine.Parsing.Entity.Parse(input);

            Assert.AreEqual("Student of University", entity.Label);
        }

        [Test]
        public void entity_LabelAndAttributes_LabelAndAttributes()
        {
            var input = "[Student of University]\r\nAge int?\r\nSalary decimal(10,2)";
            var entity = ERMine.Parsing.Entity.Parse(input);

            Assert.AreEqual("Student of University", entity.Label);
            Assert.AreEqual(2, entity.Attributes.Count);
        }

        [Test]
        public void entity_LabelAndAttributesAndKey_LabelAndAttributesAndKey()
        {
            var input = "[Student of University]\r\n*StudentNr varchar(20)\r\nAge int?\r\nSalary decimal(10,2)";
            var entity = ERMine.Parsing.Entity.Parse(input);

            Assert.AreEqual("Student of University", entity.Label);
            Assert.AreEqual(3, entity.Attributes.Count);
            Assert.AreEqual("StudentNr", entity.Key.Attributes.ElementAt(0).Label);
        }


    }
}
