﻿using System;
using NUnit.Framework;
using System.Linq;
using ERMine;
using ERMine.Modeling;

namespace ERMine.UnitTesting.Parsing
{
    [TestFixture]
    public class RelationshipParserTest
    {
        [Test]
        public void Relationship_Binary_WithLabel()
        {
            var input = "Student +-follow-* Curse";
            var relationship = ERMine.Parsing.Relationship.Parse(input);

            Assert.AreEqual("follow", relationship.Label);
            Assert.AreEqual("Student", relationship.Entities.ElementAt(0).Label);
            Assert.AreEqual(Cardinality.OneOrMore, relationship.Cardinality.ElementAt(0));
            Assert.AreEqual("Curse", relationship.Entities.ElementAt(1).Label);
            Assert.AreEqual(Cardinality.ZeroOrMore, relationship.Cardinality.ElementAt(1));
        }

        [Test]
        public void Relationship_Binary_WithoutLabel()
        {
            var input = "Post*--1Comment";
            var relationship = ERMine.Parsing.Relationship.Parse(input);

            Assert.AreEqual(null, relationship.Label);
            Assert.AreEqual("Post", relationship.Entities.ElementAt(0).Label);
            Assert.AreEqual(Cardinality.ZeroOrMore, relationship.Cardinality.ElementAt(0));
            Assert.AreEqual("Comment", relationship.Entities.ElementAt(1).Label);
            Assert.AreEqual(Cardinality.ExactyOne, relationship.Cardinality.ElementAt(1));
        }

        [Test]
        public void Relationship_Binary_Self()
        {
            var input = "Employee *-manages-1 Employee";
            var relationship = Parsing.Relationship.Parse(input);

            Assert.AreEqual("Employee", relationship.Entities.ElementAt(0).Label);
            Assert.AreEqual("Employee", relationship.Entities.ElementAt(1).Label);
            Assert.IsTrue(relationship.Entities.ElementAt(0).Label == relationship.Entities.ElementAt(1).Label);
            Assert.AreEqual(1, Parsing.Model.Entities.Count());
        }

    }
}
