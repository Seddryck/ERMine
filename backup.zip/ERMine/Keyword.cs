﻿using Sprache;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERMine
{
    class Keyword
    {
        public static readonly Parser<char> IsNullable = Parse.Char('?');
    }
}
