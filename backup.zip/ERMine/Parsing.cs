﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprache;
using ERMine.Modeling;
using ERMine.Modeling.Factory;

namespace ERMine
{
    public class Parsing
    {
        public static Model model = new Model();
        private static RelationshipFactory relationshipFactory = new RelationshipFactory(model);

        public readonly static Parser<Attribute> Attribute =
        (
            from isKey in Parse.Char('*').Optional()
            from label in Grammar.Textual
            from dataType in DataType.Optional()
            from isNullable in Keyword.IsNullable.Optional()
            select new Attribute() { Label = label, DataType=dataType.GetOrDefault(), IsNullable=isNullable.IsDefined, IsPartOfKey=isKey.IsDefined}
        );

        readonly static Parser<string> DataType =
        (
            from type in Grammar.Textual
            from additional in DataTypeLength.Or(DataTypePrecision).Optional()
            select type + additional.GetOrDefault()
        );

        readonly static Parser<string> DataTypeLength =
        (
            from open in Parse.Char('(')
            from length in Parse.Number
            from close in Parse.Char(')')
            select string.Format("({0})", length)
        );

        readonly static Parser<string> DataTypePrecision =
        (
            from open in Parse.Char('(')
            from length in Parse.Number
            from separator in Parse.Char(',')
            from precision in Parse.Number
            from close in Parse.Char(')')
            select string.Format("({0},{1})", length, precision)
        );

        public readonly static Parser<IEnumerable<Attribute>> Attributes =
        (
            Attribute.Many()
        );

        public readonly static Parser<Entity> Entity =
        (
            from label in Grammar.BracketTextual
            from attributes in Attributes.Optional()
            select attributes.IsDefined ? new Entity(label, attributes.Get()) : new Entity(label)
        );

        public readonly static Parser<Cardinality> Cardinality =
        (
            from cardinality in Parse.Char('*').Return(Modeling.Cardinality.ZeroOrMore)
                                .Or(Parse.Char('?').Return(Modeling.Cardinality.ZeroOrOne)
                                .Or(Parse.Char('1').Return(Modeling.Cardinality.ExactyOne)
                                .Or(Parse.Char('+').Return(Modeling.Cardinality.OneOrMore)
                                )))
            select cardinality
        );

        public readonly static Parser<Relationship> Relationship =
        (
            from firstEntity in Grammar.Textual
            from firstCardinality in Cardinality
            from firstSeparator in Parse.Char('-')
            from label in Grammar.Textual.Optional()
            from secondSeparator in Parse.Char('-')
            from secondCardinality in Cardinality
            from secondEntity in Grammar.Textual
            select relationshipFactory.Create(label.GetOrDefault(), firstEntity, firstCardinality, secondEntity, secondCardinality)
        );

        public readonly static Parser<IEnumerable<Relationship>> Relationships =
        (
            Relationship.Many()
        );


    }
}
