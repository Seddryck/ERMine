﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERMine.Modeling
{
    public class PrimaryKey
    {
        public IEnumerable<Attribute> Attributes { get; set; }

        public PrimaryKey(IEnumerable<Attribute> attributes)
        {
            Attributes = attributes;
        }
    }
}
