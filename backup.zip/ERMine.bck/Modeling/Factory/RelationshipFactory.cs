﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERMine.Modeling.Factory
{
    public class RelationshipFactory
    {
        private readonly Model model;

        public RelationshipFactory(Model model)
        {
            this.model = model;
        }

        public Relationship Create(string label, IEnumerable<Tuple<Entity, Cardinality>> members)
        {
            var relationship = new Relationship(members.Count());
            relationship.Label = label;
            foreach (var item in members)
                relationship.Add(item.Item1, item.Item2);
            return relationship;
        }

        public Relationship Create(string label, string firstEntity, Cardinality firstCardinality, string secondEntity, Cardinality secondCardinality)
        {
            var tuples = new List<Tuple<Entity, Cardinality>>();

            var first = model.Entities.FirstOrDefault(e => e.Label == firstEntity);
            if (first == null)
            {
                first = new Entity(firstEntity);
                model.Entities.Add(first); 
            }
            tuples.Add(new Tuple<Entity, Cardinality>(first, firstCardinality));

            var second = model.Entities.FirstOrDefault(e => e.Label == secondEntity);
            if (second == null)
            {
                second = new Entity(secondEntity);
                model.Entities.Add(second);
            }
            tuples.Add(new Tuple<Entity, Cardinality>(second, secondCardinality));
            return Create(label, tuples);
        }
    }
}
