﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERMine.Modeling.Factory
{
    public class EntityFactory
    {
        private readonly Model model;

        public EntityFactory(Model model)
        {
            this.model = model;
        }

        public Entity Create(string label, IEnumerable<Attribute> attributes)
        {
            var entity = model.Entities.FirstOrDefault(e => e.Label == label);
            if (entity == null)
                return new Entity(label, attributes);

            if (entity.Attributes == null)
            {
                entity.Define(attributes);
                return entity;
            }
            else
                throw new ArgumentException();
        }
    }
}
